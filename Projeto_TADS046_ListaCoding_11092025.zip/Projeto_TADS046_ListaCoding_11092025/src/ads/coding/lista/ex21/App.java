package ads.coding.lista.ex21;

public class App {

	public static void main(String[] args) {
		PedidoDeLanche pedido1 = new PedidoDeLanche("Hambúrguer", "Médio", true, true, false);

		
        PedidoDeLanche pedido2 = new PedidoDeLanche("Pizza", "Grande", true, true, true);


        pedido1.exibirResumo();
        pedido2.exibirResumo();
    }
}