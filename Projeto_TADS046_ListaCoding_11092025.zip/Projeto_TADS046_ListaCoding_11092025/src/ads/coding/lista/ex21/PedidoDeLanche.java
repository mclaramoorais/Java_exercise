package ads.coding.lista.ex21;

public class PedidoDeLanche {
	 private String tipo;     
	    private String tamanho;  
	    private boolean queijoExtra;
	    private boolean batata;
	    private boolean refrigerante;

	    public PedidoDeLanche(String tipo, String tamanho, boolean queijoExtra, boolean batata, boolean refrigerante) {
	        this.tipo = tipo;
	        this.tamanho = tamanho;
	        this.queijoExtra = queijoExtra;
	        this.batata = batata;
	        this.refrigerante = refrigerante;
	    }

	    public double calcularPreco() {
	        double preco = 0;

	        switch (tamanho.toLowerCase()) {
	            case "pequeno":
	                preco = 10.0;
	                break;
	            case "medio":
	            case "médio":
	                preco = 15.0;
	                break;
	            case "grande":
	                preco = 20.0;
	                break;
	            default:
	                System.out.println("Tamanho inválido, preço base = 0");
	        }

	        if (queijoExtra) preco += 2.0;
	        if (batata) preco += 5.0;
	        if (refrigerante) preco += 4.0;

	        return preco;
	    }

	    public void exibirResumo() {
	        System.out.println("PEDIDO DE LANCHE:");
	        System.out.println(" - Tipo: " + tipo);
	        System.out.println(" - Tamanho: " + tamanho);
	        System.out.println(" - Queijo extra: " + (queijoExtra ? "SIM" : "NÃO"));
	        System.out.println(" - Batata: " + (batata ? "SIM" : "NÃO"));
	        System.out.println(" - Refrigerante: " + (refrigerante ? "SIM" : "NÃO"));
	        System.out.printf(" >>> PREÇO FINAL: R$ %.2f%n", calcularPreco());
	        System.out.println();
	    }
	}