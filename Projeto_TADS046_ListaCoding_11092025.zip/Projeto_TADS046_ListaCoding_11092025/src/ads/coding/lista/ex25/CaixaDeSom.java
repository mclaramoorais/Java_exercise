package ads.coding.lista.ex25;

public class CaixaDeSom {
	 private boolean ligada;
	    private int volume;
	    private boolean mudo;

	    public CaixaDeSom() {
	        this.ligada = false;
	        this.volume = 0;
	        this.mudo = false;
	    }

	    public void ligar() {
	        if (!ligada) {
	            this.ligada = true;
	            this.volume = 10;
	            System.out.println("Caixa de som ligada. Volume: " + volume);
	        } else {
	            System.out.println("Caixa de som já está ligada.");
	        }
	    }

	    public void desligar() {
	        if (ligada) {
	            this.ligada = false;
	            this.volume = 0;
	            this.mudo = false;
	            System.out.println("Caixa de som desligada.");
	        } else {
	            System.out.println("Caixa de som já está desligada.");
	        }
	    }

	    public void aumentarVolume() {
	        if (ligada && !mudo) {
	            if (volume < 100) {
	                this.volume++;
	                System.out.println("Volume aumentado para: " + volume);
	            } else {
	                System.out.println("Volume máximo atingido.");
	            }
	        } else if (mudo) {
	            System.out.println("Caixa de som está no mudo. Desative o mudo para ajustar o volume.");
	        } else {
	            System.out.println("Caixa de som desligada. Ligue para ajustar o volume.");
	        }
	    }

	    public void diminuirVolume() {
	        if (ligada && !mudo) {
	            if (volume > 0) {
	                this.volume--;
	                System.out.println("Volume diminuído para: " + volume);
	            } else {
	                System.out.println("Volume mínimo atingido.");
	            }
	        } else if (mudo) {
	            System.out.println("Caixa de som está no mudo. Desative o mudo para ajustar o volume.");
	        } else {
	            System.out.println("Caixa de som desligada. Ligue para ajustar o volume.");
	        }
	    }

	    public void ativarMudo() {
	        if (ligada && !mudo) {
	            this.mudo = true;
	            System.out.println("Mudo ativado.");
	        } else if (!ligada) {
	            System.out.println("Caixa de som desligada. Ligue para ativar o mudo.");
	        } else {
	            System.out.println("Caixa de som já está no mudo.");
	        }
	    }

	    public void desativarMudo() {
	        if (ligada && mudo) {
	            this.mudo = false;
	            System.out.println("Mudo desativado. Volume atual: " + volume);
	        } else if (!ligada) {
	            System.out.println("Caixa de som desligada. Ligue para desativar o mudo.");
	        } else {
	            System.out.println("Caixa de som não está no mudo.");
	        }
	    }

	    public String getStatus() {
	        return "Estado: " + (ligada ? "Ligada" : "Desligada") + ", Volume: " + (mudo ? "Mudo" : volume);
	    
	}

}