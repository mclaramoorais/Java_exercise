package ads.coding.lista.ex25;

public class App {

	public static void main(String[] args) {
	    System.out.println();
	    
        CaixaDeSom caixa = new CaixaDeSom();

        System.out.println("Status inicial da caixa: " + caixa.getStatus());

        
        System.out.println("\nLigando e ajustando volume:");
        caixa.ligar();
        for (int i = 0; i < 5; i++) {
            caixa.aumentarVolume();
        }
        System.out.println("Status após aumentar volume: " + caixa.getStatus());

        
        System.out.println("\nDiminuindo volume até 0:");
        while (caixa.getStatus().contains("Volume: 0") == false) {
            caixa.diminuirVolume();
        }
        System.out.println("Status com volume 0: " + caixa.getStatus());

        
        System.out.println("\nAtivando e desativando mudo:");
        caixa.ativarMudo();
        System.out.println("Status com mudo ativado: " + caixa.getStatus());
        caixa.desativarMudo();
        System.out.println("Status com mudo desativado: " + caixa.getStatus());

        
        System.out.println("\nDesligando a caixa de som:");
        caixa.desligar();
        System.out.println("Status final: " + caixa.getStatus());
    }
}
