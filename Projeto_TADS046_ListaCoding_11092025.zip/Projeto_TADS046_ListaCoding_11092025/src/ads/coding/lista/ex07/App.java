package ads.coding.lista.ex07;

public class App {

	public static void main(String[] args) {
		 
        TermometroAmbiente sala = new TermometroAmbiente("Sala de Estar", 25.0);
        TermometroAmbiente cozinha = new TermometroAmbiente("Cozinha", 28.5);

        sala.exibirTemperatura();
        cozinha.exibirTemperatura();

        sala.atualizarTemperatura(22.0);
        cozinha.atualizarTemperatura(30.0);

        sala.exibirTemperatura();
        cozinha.exibirTemperatura();
    }
}