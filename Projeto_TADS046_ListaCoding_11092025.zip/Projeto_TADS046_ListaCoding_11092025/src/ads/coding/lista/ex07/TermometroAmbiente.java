package ads.coding.lista.ex07;

public class TermometroAmbiente {
	 private String local;
	    private double temperatura;

	    
	    public TermometroAmbiente(String local, double temperaturaInicial) {
	        this.local = local;
	        this.temperatura = temperaturaInicial;
	    }

	   
	    public void atualizarTemperatura(double novaTemp) {
	        this.temperatura = novaTemp;
	        System.out.println("Temperatura do ambiente " + local + " atualizada para " + temperatura + "°C.");
	    }

	  
	    public void exibirTemperatura() {
	        System.out.println("Ambiente: " + local + " | Temperatura atual: " + temperatura + "°C");
	    }
}
