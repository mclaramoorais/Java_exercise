package ads.coding.lista.ex01;

public class App {

	public static void main(String[] args) {
		
		 LampadaInteligente lamp1 = new LampadaInteligente();
	     LampadaInteligente lamp2 = new LampadaInteligente(true, "leitura");
	     
	        System.out.println("Estado inicial:");
	        System.out.println("Lampada 1 -> " + lamp1.getEstado());
	        System.out.println("Lampada 2 -> " + lamp2.getEstado());

	        lamp1.ligar();
	        lamp1.alterarModo("relax");
	        lamp2.alterarModo("relax");
	        
	        System.out.println("\nApós alterações:");
	        System.out.println("Lampada 1 -> " + lamp1.getEstado());
	        System.out.println("Lampada 2 -> " + lamp2.getEstado());
	        
	        lamp1.desligar();
	        System.out.println("\nApós desligar Lampada 1:");
	        System.out.println("Lampada 1 -> " + lamp1.getEstado());
	        System.out.println("Lampada 2 -> " + lamp2.getEstado());
	    }
	}
	        
