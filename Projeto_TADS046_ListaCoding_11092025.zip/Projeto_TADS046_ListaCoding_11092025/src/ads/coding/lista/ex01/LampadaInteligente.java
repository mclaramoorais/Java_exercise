package ads.coding.lista.ex01;

public class LampadaInteligente {
	private boolean ligada;
    private String modo;


public LampadaInteligente() {
    this.ligada = false;
    this.modo = "desligada";
}

public LampadaInteligente(boolean ligada, String modo) {
    this.ligada = ligada;
    this.modo = modo;
}
public void ligar() {
    this.ligada = true;
    if (this.modo.equals("desligada")) {
        this.modo = "padrão";
    }
}

public void desligar() {
    this.ligada = false;
    this.modo = "desligada";
}

public void alterarModo(String novoModo) {
    if (this.ligada) {
        this.modo = novoModo;
    } else {
        System.out.println("Não é possível alterar o modo: a lâmpada está desligada.");
    }
}

public String getEstado() {
    return "Lâmpada está " + (ligada ? "ligada" : "desligada") + " | Modo: " + modo;
}
}