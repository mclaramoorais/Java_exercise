package ads.coding.lista.ex09;

public class PlayerDeMusica {
	private String faixa;
    private String status; 
    
    public PlayerDeMusica(String faixa) {
        this.faixa = faixa;
        this.status = "Parado"; 
    }

    public void tocar() {
        status = "Tocando";
        System.out.println("Tocando a faixa: " + faixa);
    }

    public void pausar() {
        if (status.equals("Tocando")) {
            status = "Pausado";
            System.out.println("Faixa pausada: " + faixa);
        } else {
            System.out.println("Não é possível pausar. O player não está tocando.");
        }
    }
    
    public void parar() {
        if (!status.equals("Parado")) {
            status = "Parado";
            System.out.println("Reprodução parada: " + faixa);
        } else {
            System.out.println("O player já está parado.");
        }
    }

    public void exibirStatus() {
        System.out.println("Faixa: " + faixa + " | Status: " + status);
    }
}

