package ads.coding.lista.ex09;

public class App {

	public static void main(String[] args) {
		   PlayerDeMusica player1 = new PlayerDeMusica("Yellow - Coldplay");
	        PlayerDeMusica player2 = new PlayerDeMusica("Cold - Maroon 5");

	        player1.exibirStatus();
	        player2.exibirStatus();

	        player1.tocar();
	        player1.pausar();
	        player1.parar();

	        player2.tocar();

	        player1.exibirStatus();
	        player2.exibirStatus();
	    }
	}