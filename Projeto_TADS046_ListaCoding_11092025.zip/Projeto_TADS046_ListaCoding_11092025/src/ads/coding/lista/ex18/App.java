package ads.coding.lista.ex18;

public class App {

	public static void main(String[] args) {
		  AlarmeResidencial alarme = new AlarmeResidencial();

	        alarme.exibirStatus();
	        alarme.dispararEvento("Porta aberta");

	        alarme.armar();
	        alarme.dispararEvento("Janela quebrada");

	        alarme.desarmar();
	        alarme.dispararEvento("Movimento detectado");
	    }
	}