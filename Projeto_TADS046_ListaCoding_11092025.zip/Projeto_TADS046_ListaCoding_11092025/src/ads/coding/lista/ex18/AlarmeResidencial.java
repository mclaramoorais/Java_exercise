package ads.coding.lista.ex18;

public class AlarmeResidencial {
	private boolean armado;

    public AlarmeResidencial() {
        this.armado = false;
    }

    public void armar() {
        armado = true;
        System.out.println("Alarme armado.");
    }

    public void desarmar() {
        armado = false;
        System.out.println("Alarme desarmado.");
    }

    public void dispararEvento(String evento) {
        System.out.println("Evento detectado: " + evento);
        if (armado) {
            System.out.println("Alarme disparado! Atenção!");
        } else {
            System.out.println("Alarme não disparou. Sistema desarmado.");
        }
    }

    public void exibirStatus() {
        System.out.println("Status do alarme: " + (armado ? "Armado" : "Desarmado"));
    }
}
