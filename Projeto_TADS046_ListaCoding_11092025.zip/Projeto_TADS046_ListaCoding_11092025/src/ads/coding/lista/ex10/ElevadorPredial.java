package ads.coding.lista.ex10;

public class ElevadorPredial {
	 private int andarAtual;
	    private int andarMinimo;
	    private int andarMaximo;

	   
	    public ElevadorPredial(int andarMinimo, int andarMaximo) {
	        this.andarMinimo = andarMinimo;
	        this.andarMaximo = andarMaximo;
	        this.andarAtual = andarMinimo; 
	    }

	    public void subir() {
	        if (andarAtual < andarMaximo) {
	            andarAtual++;
	            System.out.println("Subindo para o andar " + andarAtual);
	        } else {
	            System.out.println("Não é possível subir. Já está no último andar (" + andarMaximo + ").");
	        }
	    }
	    
	    public void descer() {
	        if (andarAtual > andarMinimo) {
	            andarAtual--;
	            System.out.println("Descendo para o andar " + andarAtual);
	        } else {
	            System.out.println("Não é possível descer. Já está no térreo (" + andarMinimo + ").");
	        }
	    }

	    public void exibirAndar() {
	        System.out.println("Andar atual: " + andarAtual);
	    }
}
