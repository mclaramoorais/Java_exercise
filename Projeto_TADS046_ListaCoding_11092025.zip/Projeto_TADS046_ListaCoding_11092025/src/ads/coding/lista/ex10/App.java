package ads.coding.lista.ex10;

public class App {

	public static void main(String[] args) {
		 ElevadorPredial elevador = new ElevadorPredial(0, 5);

	        elevador.exibirAndar();

	        elevador.subir();
	        elevador.subir();
	        elevador.subir();
	        elevador.subir();
	        elevador.subir();
	        elevador.subir();

	        elevador.descer();
	        elevador.descer();
	        elevador.descer();
	        elevador.descer();
	        elevador.descer();
	        elevador.descer();

	        elevador.exibirAndar();
	    }
	}