package ads.coding.lista.ex29;

public class App {

	public static void main(String[] args) {
		  TanqueDeAgua tanque = new TanqueDeAgua(100.0);

	        System.out.println("Enchendo o tanque...");
	        tanque.encher(50.0);
	        tanque.encher(60.0);

	        System.out.println("\nEsvaziando o tanque...");
	        tanque.esvaziar(30.0);
	        tanque.esvaziar(50.0);
	        tanque.esvaziar(50.0); 
	    }
	}