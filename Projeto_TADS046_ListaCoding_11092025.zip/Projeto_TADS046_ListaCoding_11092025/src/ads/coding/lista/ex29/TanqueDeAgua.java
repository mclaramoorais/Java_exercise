package ads.coding.lista.ex29;

public class TanqueDeAgua {
	private double nivelAtual;
    private final double capacidadeMaxima;
    private final double capacidadeMinima;

    public TanqueDeAgua(double capacidadeMaxima) {
        this.capacidadeMaxima = capacidadeMaxima;
        this.capacidadeMinima = 0.0;
        this.nivelAtual = 0.0;
    }

    public void encher(double quantidade) {
        nivelAtual += quantidade;
        if (nivelAtual >= capacidadeMaxima) {
            nivelAtual = capacidadeMaxima;
            System.out.println("Nível de água no tanque: " + nivelAtual + " litros (capacidade máxima).");
        } else {
            exibirNivel();
        }
    }

    public void esvaziar(double quantidade) {
        nivelAtual -= quantidade;
        if (nivelAtual <= capacidadeMinima) {
            nivelAtual = capacidadeMinima;
            System.out.println("Nível de água no tanque: " + nivelAtual + " litros (tanque vazio).");
        } else {
            exibirNivel();
        }
    }

    private void exibirNivel() {
        System.out.println("Nível de água no tanque: " + nivelAtual + " litros.");
    }
}