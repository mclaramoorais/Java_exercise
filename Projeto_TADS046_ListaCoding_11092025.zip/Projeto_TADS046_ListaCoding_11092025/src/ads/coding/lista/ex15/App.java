package ads.coding.lista.ex15;

public class App {

	public static void main(String[] args) {
		   Semaforo cruzamento1 = new Semaforo("Semáforo 1");
	        Semaforo cruzamento2 = new Semaforo("Semáforo 2");

	        int totalCiclos = 4;

	        System.out.println("Ciclos dos semáforos:");
	        for (int i = 1; i <= totalCiclos; i++) {
	            System.out.println("Ciclo " + i + ": " 
	                + cruzamento1.getNome() + "=" + cruzamento1.getEstado() + ", "
	                + cruzamento2.getNome() + "=" + cruzamento2.getEstado());
	            
	            cruzamento1.proximoEstado();
	            cruzamento2.proximoEstado();
	        }
	    }
	}