package ads.coding.lista.ex15;

public class Semaforo {
	private String estado; 
    private String nome;   

    public Semaforo(String nome) {
        this.nome = nome;
        this.estado = "vermelho"; 
    }

    public void proximoEstado() {
        switch (estado.toLowerCase()) {
            case "vermelho":
                estado = "verde";
                break;
            case "verde":
                estado = "amarelo";
                break;
            case "amarelo":
                estado = "vermelho";
                break;
            default:
                estado = "vermelho";
        }
    }

    public String getEstado() {
        return estado;
    }

    public String getNome() {
        return nome;
    }
}