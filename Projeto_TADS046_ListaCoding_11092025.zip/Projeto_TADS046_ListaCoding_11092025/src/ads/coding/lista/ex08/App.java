package ads.coding.lista.ex08;

public class App {

	public static void main(String[] args) {
		
        RelogioDigital relogio1 = new RelogioDigital(14, 30); // 14:30
        RelogioDigital relogio2 = new RelogioDigital(9, 45);  // 09:45

        
        relogio1.exibirHorario();
        relogio2.exibirHorario();

   
        relogio1.ajustarHorario(15, 10); // novo horário para relogio1
        relogio2.ajustarHorario(23, 59); // novo horário para relogio2


        relogio1.exibirHorario();
        relogio2.exibirHorario();
    }
}