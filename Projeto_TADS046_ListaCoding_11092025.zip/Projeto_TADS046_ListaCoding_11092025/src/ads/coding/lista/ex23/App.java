package ads.coding.lista.ex23;

public class App {

	public static void main(String[] args) {
		System.out.println("Geladeira");
		 
        Geladeira geladeira = new Geladeira(4);
 
        System.out.println("Status inicial da geladeira: " + geladeira.getStatus());
 
        
        System.out.println("\nAbrindo e fechando a porta:");
        geladeira.abrirPorta();
        System.out.println("Status após abrir: " + geladeira.getStatus());
        geladeira.fecharPorta();
        System.out.println("Status após fechar: " + geladeira.getStatus());
 
        
        System.out.println("\nAjustando temperatura:");
        geladeira.ajustarTemperatura(2);
        System.out.println("Status após ajuste: " + geladeira.getStatus());
        geladeira.ajustarTemperatura(0);
        System.out.println("Status final: " + geladeira.getStatus());
    }
}
 