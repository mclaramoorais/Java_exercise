package ads.coding.lista.ex23;

public class Geladeira {
	private int temperaturaInterna;
    private boolean portaAberta;
 
    public Geladeira(int temperaturaInicial) {
        this.temperaturaInterna = temperaturaInicial;
        this.portaAberta = false;
    }
 
    public void ajustarTemperatura(int novaTemperatura) {
        if (novaTemperatura >= 1 && novaTemperatura <= 7) {
            this.temperaturaInterna = novaTemperatura;
            System.out.println("Temperatura interna ajustada para: " + temperaturaInterna + "°C.");
        } else {
            System.out.println("Temperatura inválida. Deve ser entre 1°C e 7°C.");
        }
    }
 
    public void abrirPorta() {
        if (!portaAberta) {
            this.portaAberta = true;
            System.out.println("Porta da geladeira aberta.");
        } else {
            System.out.println("Porta já está aberta.");
        }
    }
 
    public void fecharPorta() {
        if (portaAberta) {
            this.portaAberta = false;
            System.out.println("Porta da geladeira fechada.");
        } else {
            System.out.println("Porta já está fechada.");
        }
    }
 
    public String getStatus() {
        return "Temperatura: " + temperaturaInterna + "°C, Porta: " + (portaAberta ? "Aberta" : "Fechada");
    }
}