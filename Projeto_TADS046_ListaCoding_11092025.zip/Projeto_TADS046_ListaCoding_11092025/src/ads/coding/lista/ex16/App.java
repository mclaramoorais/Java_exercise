package ads.coding.lista.ex16;

public class App {

	public static void main(String[] args) {
		Impressora impressora = new Impressora(0, 0);

        impressora.imprimir(5);
        impressora.exibirStatus();

        impressora.reabastecerPapel(10);
        impressora.reabastecerTinta(10);

        impressora.imprimir(5);
        impressora.exibirStatus();
    }
}