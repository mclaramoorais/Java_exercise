package ads.coding.lista.ex16;

public class Impressora {
	private int papel; 
    private int tinta; 

    
    public Impressora(int papel, int tinta) {
        this.papel = papel;
        this.tinta = tinta;
    }

 
    public void imprimir(int paginas) {
        if (paginas <= 0) {
            System.out.println("Número de páginas inválido.");
            return;
        }

        if (papel >= paginas && tinta >= paginas) {
            papel -= paginas;
            tinta -= paginas;
            System.out.println("Imprimindo " + paginas + " página(s). Impressão concluída.");
        } else {
            System.out.println("Não há insumos suficientes para imprimir " + paginas + " página(s).");
        }
    }

    public void reabastecerPapel(int folhas) {
        if (folhas > 0) {
            papel += folhas;
            System.out.println("Reabastecido " + folhas + " folha(s). Total de papel: " + papel);
        }
    }

    public void reabastecerTinta(int quantidade) {
        if (quantidade > 0) {
            tinta += quantidade;
            System.out.println("Reabastecido tinta para " + quantidade + " página(s). Total de tinta: " + tinta);
        }
    }

    public void exibirStatus() {
        System.out.println("Status -> Papel: " + papel + ", Tinta: " + tinta);
    }
}
