package ads.coding.lista.ex04;

public class App {
    public static void main(String[] args) {
        VentiladorDeMesa vent1 = new VentiladorDeMesa();
        VentiladorDeMesa vent2 = new VentiladorDeMesa();

        System.out.println("=== Ventilador 1 ===");
        vent1.ligar();
        vent1.mudarVelocidade(2);
        vent1.mudarVelocidade(3);
        vent1.desligar();
        System.out.println("Estado final Ventilador 1 -> " + vent1.getEstado());

        System.out.println();

        System.out.println("=== Ventilador 2 ===");
        vent2.mudarVelocidade(2);
        vent2.ligar();
        vent2.mudarVelocidade(3);
        vent2.desligar();
        System.out.println("Estado final Ventilador 2 -> " + vent2.getEstado());
    }
}