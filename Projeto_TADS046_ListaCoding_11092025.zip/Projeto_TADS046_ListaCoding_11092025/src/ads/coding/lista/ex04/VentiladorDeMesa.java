package ads.coding.lista.ex04;

public class VentiladorDeMesa {
    private boolean ligado;
    private int velocidade; 
    //0 = desligado, 1 = fraco, 2 = médio, 3 = forte

    public void ligar() {
        if (!ligado) {
            ligado = true;
            velocidade = 1; 
            System.out.println("O ventilador foi ligado na velocidade 1 (fraco).");
        } else {
            System.out.println("O ventilador já está ligado.");
        }
    }

    public void desligar() {
        if (ligado) {
            ligado = false;
            velocidade = 0;
            System.out.println("O ventilador foi desligado.");
        } else {
            System.out.println("O ventilador já está desligado.");
        }
    }

    public void mudarVelocidade(int novaVelocidade) {
        if (ligado) {
            if (novaVelocidade >= 1 && novaVelocidade <= 3) {
                velocidade = novaVelocidade;
                System.out.println("Velocidade alterada para nível " + novaVelocidade + ".");
            } else {
                System.out.println("Velocidade inválida. Use 1 (fraco), 2 (médio) ou 3 (forte).");
            }
        } else {
            System.out.println("Não é possível mudar velocidade: o ventilador está desligado.");
        }
    }

    public String getEstado() {
        return "Ventilador está " + (ligado ? "ligado" : "desligado") +
               " | Velocidade: " + velocidade;
    }
}

