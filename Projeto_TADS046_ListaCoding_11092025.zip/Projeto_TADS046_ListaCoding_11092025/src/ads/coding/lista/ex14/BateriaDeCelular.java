package ads.coding.lista.ex14;

public class BateriaDeCelular {
	 private int nivelCarga; 

	 
	    public BateriaDeCelular(int nivelInicial) {
	        if (nivelInicial < 0) nivelInicial = 0;
	        if (nivelInicial > 100) nivelInicial = 100;
	        this.nivelCarga = nivelInicial;
	    }

	  
	    public void consumir(int quantidade) {
	        if (quantidade < 0) {
	            System.out.println("Quantidade inválida para consumo.");
	            return;
	        }
	        if (nivelCarga - quantidade < 0) {
	            System.out.println("Bateria quase esgotada! Ajustando para 0%.");
	            nivelCarga = 0;
	        } else {
	            nivelCarga -= quantidade;
	            System.out.println("Consumindo " + quantidade + "%. Nível atual: " + nivelCarga + "%");
	        }
	    }


	    public void recarregar(int quantidade) {
	        if (quantidade < 0) {
	            System.out.println("Quantidade inválida para recarga.");
	            return;
	        }
	        if (nivelCarga + quantidade > 100) {
	            nivelCarga = 100;
	        } else {
	            nivelCarga += quantidade;
	        }
	        System.out.println("Recarga de " + quantidade + "%. Nível atual: " + nivelCarga + "%");
	    }


	    public void exibirNivel() {
	        System.out.println("Nível de carga atual: " + nivelCarga + "%");
	    }
	}

