package ads.coding.lista.ex14;

public class App {

	public static void main(String[] args) {
		  BateriaDeCelular bateria = new BateriaDeCelular(50);

	        bateria.exibirNivel();

	        bateria.consumir(30);
	        bateria.consumir(25); 

	        bateria.recarregar(40);
	        bateria.recarregar(70); 
	        
	        bateria.exibirNivel();
	    }
	}