package ads.coding.lista.ex11;

public class App {

	public static void main(String[] args) {
		 ControleDeVolume controle = new ControleDeVolume(0, 10);

	        controle.exibirVolume();

	        controle.aumentarVolume(3);
	        controle.aumentarVolume(5);
	        controle.aumentarVolume(4); 

	        controle.diminuirVolume(2);
	        controle.diminuirVolume(10); 
	        controle.exibirVolume();
	    }
	}