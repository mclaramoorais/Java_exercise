package ads.coding.lista.ex11;

public class ControleDeVolume {
	 private int volume;
	    private int volumeMinimo;
	    private int volumeMaximo;

	    public ControleDeVolume(int volumeMinimo, int volumeMaximo) {
	        this.volumeMinimo = volumeMinimo;
	        this.volumeMaximo = volumeMaximo;
	        this.volume = volumeMinimo;
	    }

	    public void aumentarVolume(int valor) {
	        if (volume + valor > volumeMaximo) {
	            volume = volumeMaximo;
	            System.out.println("Volume atingiu o máximo: " + volume);
	        } else {
	            volume += valor;
	            System.out.println("Volume aumentado para: " + volume);
	        }
	    }

	    public void diminuirVolume(int valor) {
	        if (volume - valor < volumeMinimo) {
	            volume = volumeMinimo;
	            System.out.println("Volume atingiu o mínimo: " + volume);
	        } else {
	            volume -= valor;
	            System.out.println("Volume diminuído para: " + volume);
	        }
	    }

	    public void exibirVolume() {
	        System.out.println("Volume atual: " + volume);
	    }
	}

