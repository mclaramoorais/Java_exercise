package ads.coding.lista.ex22;

public class App {

	public static void main(String[] args) {
		 FornoEletrico forno1 = new FornoEletrico("FORNO 1");
	        forno1.ligar();
	        forno1.setTemperaturaAlvo(180);
	        forno1.aquecer();
	        forno1.desligar();

	        System.out.println();

	        FornoEletrico forno2 = new FornoEletrico("FORNO 2");
	        forno2.ligar();
	        forno2.setTemperaturaAlvo(220);
	        forno2.aquecer();
	        forno2.desligar();
	    }
	}
