package ads.coding.lista.ex22;

public class FornoEletrico {
	 private String id;
	    private boolean ligado;
	    private int temperaturaAtual;
	    private int temperaturaAlvo;

	    public FornoEletrico(String id) {
	        this.id = id;
	        this.ligado = false;
	        this.temperaturaAtual = 25; 
	        this.temperaturaAlvo = 0;
	    }

	    public void ligar() {
	        ligado = true;
	        System.out.println(id + ": STATUS = LIGADO | Temperatura atual = " + temperaturaAtual + "°C");
	    }

	    public void desligar() {
	        ligado = false;
	        System.out.println(id + ": STATUS = DESLIGADO | Temperatura final = " + temperaturaAtual + "°C");
	    }

	    public void setTemperaturaAlvo(int temperatura) {
	        if (ligado) {
	            temperaturaAlvo = temperatura;
	            System.out.println(id + ": Temperatura-alvo definida para " + temperaturaAlvo + "°C");
	        } else {
	            System.out.println(id + ": FALHA: Não é possível definir temperatura com o forno desligado.");
	        }
	    }

	    public void aquecer() {
	        if (!ligado) {
	            System.out.println(id + ": FALHA: O forno está desligado.");
	            return;
	        }

	        System.out.println(id + ": Iniciando aquecimento até " + temperaturaAlvo + "°C...");

	        while (temperaturaAtual < temperaturaAlvo) {
	            temperaturaAtual += 20;
	            if (temperaturaAtual > temperaturaAlvo) temperaturaAtual = temperaturaAlvo;


	            if (temperaturaAtual % 40 == 5 || temperaturaAtual == temperaturaAlvo) {
	                System.out.println(id + ": Temperatura atual = " + temperaturaAtual + "°C");
	            }
	        }

	        System.out.println(id + ": Meta atingida! Temperatura estável em " + temperaturaAtual + "°C");
	    }
	}