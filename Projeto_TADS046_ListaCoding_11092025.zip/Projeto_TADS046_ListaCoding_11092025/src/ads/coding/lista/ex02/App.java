package ads.coding.lista.ex02;

public class App {

	public static void main(String[] args) {
		 PortaComTranca porta = new PortaComTranca();

	        System.out.println("Estado inicial:");
	        System.out.println(porta.getEstado());

	        
	        System.out.println("\nTentando abrir porta trancada:");
	        porta.abrir();
	        System.out.println(porta.getEstado());

	      
	        System.out.println("\nDestrancando e abrindo:");
	        porta.destrancar();
	        porta.abrir();
	        System.out.println(porta.getEstado());

	        
	        System.out.println("\nFechando e trancando:");
	        porta.fechar();
	        porta.trancar();
	        System.out.println(porta.getEstado());
	    }
	}
	
