package ads.coding.lista.ex02;

public class PortaComTranca {
	private boolean aberta;
    private boolean trancada;

    
    public PortaComTranca() {
        this.aberta = false;
        this.trancada = true; 
    }

    public PortaComTranca(boolean aberta, boolean trancada) {
        this.aberta = aberta;
        this.trancada = trancada;
    }


    public void trancar() {
        if (!aberta) {
            this.trancada = true;
            System.out.println("A porta foi trancada.");
        } else {
            System.out.println("Não é possível trancar uma porta aberta!");
        }
    }

    public void destrancar() {
        this.trancada = false;
        System.out.println("A porta foi destrancada.");
    }

    public void abrir() {
        if (trancada) {
            System.out.println("A porta está trancada! Não pode abrir.");
        } else if (aberta) {
            System.out.println("A porta já está aberta.");
        } else {
            this.aberta = true;
            System.out.println("A porta foi aberta.");
        }
    }

    public void fechar() {
        if (aberta) {
            this.aberta = false;
            System.out.println("A porta foi fechada.");
        } else {
            System.out.println("A porta já está fechada.");
        }
    }

    public String getEstado() {
        return "A Porta está " + (aberta ? "aberta" : "fechada") +
               " e " + (trancada ? "trancada" : "destrancada");
    }
}


