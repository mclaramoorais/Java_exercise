package ads.coding.lista.ex05;

public class TelevisaoSimples {
	private boolean ligada;
    private int canal;
    private int volume;

    public TelevisaoSimples() {
        ligada = false;
        canal = 1;   
        volume = 10; 
    }

    public void ligar() {
        if (!ligada) {
            ligada = true;
            System.out.println("A TV foi ligada no canal " + canal + " com volume " + volume + ".");
        } else {
            System.out.println("A TV já está ligada.");
        }
    }

    public void desligar() {
        if (ligada) {
            ligada = false;
            System.out.println("A TV foi desligada.");
        } else {
            System.out.println("A TV já está desligada.");
        }
    }

    public void trocarCanal(int novoCanal) {
        if (ligada) {
            if (novoCanal > 0) {
                canal = novoCanal;
                System.out.println("Canal modificado para " + canal + ".");
            } else {
                System.out.println("Número de canal inválido.");
            }
        } else {
            System.out.println("Não é possível mudar de canal: a TV está desligada.");
        }
    }

    public void ajustarVolume(int novoVolume) {
        if (ligada) {
            if (novoVolume >= 0 && novoVolume <= 100) {
                volume = novoVolume;
                System.out.println("Volume modificado para " + volume + ".");
            } else {
                System.out.println("Volume inválido (0 a 100).");
            }
        } else {
            System.out.println("Não é possível mudar o volume: a TV está desligada.");
        }
    }

    public String getEstado() {
        return "TV " + (ligada ? "ligada" : "desligada") + 
               " | Canal: " + canal + " | Volume: " + volume;
    }
}


