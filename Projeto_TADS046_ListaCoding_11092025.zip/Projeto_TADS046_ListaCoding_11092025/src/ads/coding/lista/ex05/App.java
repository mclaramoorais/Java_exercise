package ads.coding.lista.ex05;

public class App {

	public static void main(String[] args) {
		TelevisaoSimples tv1 = new TelevisaoSimples();
        TelevisaoSimples tv2 = new TelevisaoSimples();

        System.out.println("=== TV 1 ===");
        tv1.ligar();
        tv1.trocarCanal(5);
        tv1.ajustarVolume(25);
        System.out.println("Estado final TV 1 -> " + tv1.getEstado());

        System.out.println();

        System.out.println("=== TV 2 ===");
        tv2.ligar();
        tv2.trocarCanal(12);
        tv2.ajustarVolume(50);
        tv2.desligar();
        System.out.println("Estado final TV 2 -> " + tv2.getEstado());
    }
}
		
		