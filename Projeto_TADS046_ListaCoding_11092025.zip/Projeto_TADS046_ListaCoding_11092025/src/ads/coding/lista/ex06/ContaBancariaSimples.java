package ads.coding.lista.ex06;

public class ContaBancariaSimples {
	 private String titular;
	    private double saldo;

	    // Construtor
	    public ContaBancariaSimples(String titular, double saldoInicial) {
	        this.titular = titular;
	        this.saldo = saldoInicial;
	    }

	    // Método de depósito
	    public void depositar(double valor) {
	        if (valor > 0) {
	            saldo += valor;
	            System.out.println("Depósito de R$" + valor + " realizado com sucesso.");
	        } else {
	            System.out.println("Valor de depósito inválido.");
	        }
	    }

	    // Método de saque
	    public void sacar(double valor) {
	        if (valor > 0 && valor <= saldo) {
	            saldo -= valor;
	            System.out.println("Saque de R$" + valor + " realizado com sucesso.");
	        } else {
	            System.out.println("Saque não realizado. Saldo insuficiente ou valor inválido.");
	        }
	    }

	    // Método para verificar saldo
	    public void exibirSaldo() {
	        System.out.println("Titular: " + titular + " | Saldo atual: R$" + saldo);
	    }
}


