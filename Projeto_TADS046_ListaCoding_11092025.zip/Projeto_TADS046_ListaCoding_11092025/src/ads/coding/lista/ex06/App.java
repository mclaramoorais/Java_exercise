package ads.coding.lista.ex06;

public class App {

	public static void main(String[] args) {
		 // Criando conta
        ContaBancariaSimples conta1 = new ContaBancariaSimples("Maria", 500.0);

        // Saldo inicial
        conta1.exibirSaldo();

        // Operações
        conta1.depositar(200.0);
        conta1.exibirSaldo();

        conta1.sacar(300.0);   // saque válido
        conta1.exibirSaldo();

        conta1.sacar(500.0);   // saque inválido (saldo insuficiente)
        conta1.exibirSaldo();
    }
}