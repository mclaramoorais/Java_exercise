package ads.coding.lista.ex24;

public class Cofre {
	private String senha;
    private boolean aberto;
 
    public Cofre(String senhaInicial) {
        this.senha = senhaInicial;
        this.aberto = false;
    }
 
    public boolean abrir(String tentativaSenha) {
        if (this.senha.equals(tentativaSenha)) {
            this.aberto = true;
            System.out.println("Cofre aberto com sucesso!");
            return true;
        } else {
            System.out.println("Senha incorreta. Cofre permanece fechado.");
            return false;
        }
    }
 
    public void fechar() {
        if (aberto) {
            this.aberto = false;
            System.out.println("Cofre fechado.");
        } else {
            System.out.println("Cofre já está fechado.");
        }
    }
 
    public void alterarSenha(String senhaAntiga, String novaSenha) {
        if (aberto) {
            if (this.senha.equals(senhaAntiga)) {
                this.senha = novaSenha;
                System.out.println("Senha alterada com sucesso!");
            } else {
                System.out.println("Senha antiga incorreta. Não foi possível alterar a senha.");
            }
        } else {
            System.out.println("Cofre precisa estar aberto para alterar a senha.");
        }
    }
 
    public String getStatus() {
        return "Estado: " + (aberto ? "Aberto" : "Fechado");
    }
}