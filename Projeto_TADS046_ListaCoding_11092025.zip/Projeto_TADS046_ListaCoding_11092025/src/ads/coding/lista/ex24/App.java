package ads.coding.lista.ex24;

public class App {

	public static void main(String[] args) {
		System.out.println("Cofre");
		 
        Cofre meuCofre = new Cofre("1234");
 
        System.out.println("Status inicial do cofre: " + meuCofre.getStatus());
 
       
        System.out.println("\nTentando abrir com senha errada:");
        meuCofre.abrir("0000");
        System.out.println("Status após tentativa: " + meuCofre.getStatus());
 
      
        System.out.println("\nAbrindo com senha correta e alterando senha:");
        if (meuCofre.abrir("1234")) {
            meuCofre.alterarSenha("1234", "4321");
            meuCofre.fechar();
        }
        System.out.println("Status após alteração e fechamento: " + meuCofre.getStatus());
 
        
        System.out.println("\nTentando abrir com a senha antiga:");
        meuCofre.abrir("1234");
        System.out.println("Status final: " + meuCofre.getStatus());
 
       
        System.out.println("\nTentando abrir com a nova senha:");
        meuCofre.abrir("4321");
        System.out.println("Status final: " + meuCofre.getStatus());
    
 
	}
 
}
	
