package ads.coding.lista.ex20;

public class Liquidificador {
	private boolean ligado;
    private int velocidade;

    public Liquidificador() {
        this.ligado = false;
        this.velocidade = 0;
    }

    public void ligar() {
        ligado = true;
        System.out.println("LIQUIDIFICADOR: STATUS = LIGADO");
    }

    public void desligar() {
        ligado = false;
        velocidade = 0;
        System.out.println("LIQUIDIFICADOR: STATUS = DESLIGADO | Velocidade = 0");
    }

    public void setVelocidade(int velocidade) {
        if (ligado) {
            if (velocidade >= 1 && velocidade <= 10) {
                this.velocidade = velocidade;
                System.out.println("LIQUIDIFICADOR: VELOCIDADE definida para " + velocidade);
            } else {
                System.out.println("LIQUIDIFICADOR: FALHA: Velocidade inválida (permitido 1 a 10)");
            }
        } else {
            System.out.println("LIQUIDIFICADOR: FALHA: Não é possível ajustar velocidade. STATUS = DESLIGADO");
        }
    }

    public void processar(String alimento) {
        if (ligado && velocidade > 0) {
            System.out.println("LIQUIDIFICADOR: PROCESSANDO " + alimento + " | Velocidade = " + velocidade);
        } else if (!ligado) {
            System.out.println("LIQUIDIFICADOR: FALHA: Tentativa de processar " + alimento + ". STATUS = DESLIGADO");
        } else {
            System.out.println("LIQUIDIFICADOR: FALHA: Velocidade não definida para processar " + alimento);
        }
    }
}