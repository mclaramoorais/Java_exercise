package ads.coding.lista.ex20;

public class App {

	public static void main(String[] args) {
		 Liquidificador liq = new Liquidificador();

	        liq.processar("vitamina de morango");

	        liq.ligar();
	        liq.setVelocidade(7);
	        liq.processar("vitamina de morango");

	        liq.desligar();
	    }
	}