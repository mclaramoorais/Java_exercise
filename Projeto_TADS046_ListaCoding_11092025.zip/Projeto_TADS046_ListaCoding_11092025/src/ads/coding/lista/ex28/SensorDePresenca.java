package ads.coding.lista.ex28;

public class SensorDePresenca {
	private boolean ativo;
    private boolean detectouPresenca;
 
    public SensorDePresenca() {
        this.ativo = false;
        this.detectouPresenca = false;
    }
 
    public void ativar() {
        if (!ativo) {
            this.ativo = true;
            System.out.println("Sensor de presença ativado.");
        } else {
            System.out.println("Sensor já está ativo.");
        }
    }
 
    public void desativar() {
        if (ativo) {
            this.ativo = false;
            this.detectouPresenca = false; 
            System.out.println("Sensor de presença desativado.");
        } else {
            System.out.println("Sensor já está desativado.");
        }
    }
 
    public void simularDeteccao() {
        if (ativo) {
            this.detectouPresenca = true;
            System.out.println("PRESENÇA DETECTADA! Acionando algo...");
        } else {
            System.out.println("Presença detectada, mas o sensor está inativo. Nenhuma ação.");
        }
    }
 
    public void resetarDeteccao() {
        this.detectouPresenca = false;
        System.out.println("Detecção de presença resetada.");
    }
 
    public String getStatus() {
        return "Estado: " + (ativo ? "Ativo" : "Inativo") + ", Presença: " + (detectouPresenca ? "Detectada" : "Não Detectada");
    }
}
