package ads.coding.lista.ex28;

public class App {

	public static void main(String[] args) {
		System.out.println("Sensor de Presença");
		 
        SensorDePresenca sensor = new SensorDePresenca();

        System.out.println("Status inicial do sensor: " + sensor.getStatus());

        
        System.out.println("\nSimulando detecção com sensor inativo:");
        sensor.simularDeteccao();
        System.out.println("Status após detecção: " + sensor.getStatus());

        
        System.out.println("\nAtivando sensor e simulando detecção:");
        sensor.ativar();
        sensor.simularDeteccao();
        System.out.println("Status após ativar e detectar: " + sensor.getStatus());

        
        System.out.println("\nResetando detecção e desativando sensor:");
        sensor.resetarDeteccao();
        sensor.desativar();
        System.out.println("Status final: " + sensor.getStatus());
    

}

}