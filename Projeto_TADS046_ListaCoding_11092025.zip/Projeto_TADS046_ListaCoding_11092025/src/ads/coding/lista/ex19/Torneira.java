package ads.coding.lista.ex19;

public class Torneira {
	private boolean aberta;
    private int intensidade;

    public Torneira() {
        aberta = false;
        intensidade = 0;
    }

    public void abrir() {
        aberta = true;
    }

    public void fechar() {
        aberta = false;
        intensidade = 0;
    }

    public void ajustarIntensidade(int valor) {
        if (valor < 0) valor = 0;
        if (valor > 10) valor = 10;
        intensidade = valor;
    }

    public int getIntensidade() {
        return aberta ? intensidade : 0;
    }

    public void exibirStatus(String nome) {
        if (getIntensidade() == 0) {
            System.out.println(nome + " = Intensidade 0 (Fechada)");
        } else {
            System.out.println(nome + " = Intensidade " + getIntensidade());
        }
    }
}