package ads.coding.lista.ex19;

public class App {

	public static void main(String[] args) {
		  Torneira torneira1 = new Torneira();
	        Torneira torneira2 = new Torneira();

	        System.out.println("Ciclo 1:");
	        torneira1.abrir();
	        torneira1.ajustarIntensidade(4);
	        torneira2.fechar();
	        torneira1.exibirStatus("Torneira 1");
	        torneira2.exibirStatus("Torneira 2");

	        System.out.println("\nCiclo 2:");
	        torneira2.abrir();
	        torneira2.ajustarIntensidade(3);
	        torneira1.exibirStatus("Torneira 1");
	        torneira2.exibirStatus("Torneira 2");

	        System.out.println("\nCiclo 3:");
	        torneira1.fechar();
	        torneira2.ajustarIntensidade(5);
	        torneira1.exibirStatus("Torneira 1");
	        torneira2.exibirStatus("Torneira 2");

	        System.out.println("\nCiclo 4:");
	        torneira1.abrir();
	        torneira1.ajustarIntensidade(8);
	        torneira2.ajustarIntensidade(2);
	        torneira1.exibirStatus("Torneira 1");
	        torneira2.exibirStatus("Torneira 2");
	    }
	}