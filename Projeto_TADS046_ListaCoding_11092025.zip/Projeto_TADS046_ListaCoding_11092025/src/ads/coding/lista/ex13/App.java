package ads.coding.lista.ex13;

public class App {

	public static void main(String[] args) {
		 MaquinaDeCafe maquina = new MaquinaDeCafe(120, 20, 3);

	        maquina.prepararCafe("expresso");
	        maquina.exibirRecursos();

	        maquina.prepararCafe("cappuccino");
	        maquina.exibirRecursos();

	        maquina.prepararCafe("latte");
	        maquina.exibirRecursos();
	    }
	}