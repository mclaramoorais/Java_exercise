package ads.coding.lista.ex13;

public class MaquinaDeCafe {
	  private int agua;       
	    private int cafe;      
	    private int acucar;     

	    public MaquinaDeCafe(int agua, int cafe, int acucar) {
	        this.agua = agua;
	        this.cafe = cafe;
	        this.acucar = acucar;
	    }

	    public void prepararCafe(String tipo) {
	        int aguaNecessaria = 0;
	        int cafeNecessario = 0;
	        int acucarNecessario = 0;

	        switch (tipo.toLowerCase()) {
	            case "expresso":
	                aguaNecessaria = 30;
	                cafeNecessario = 7;
	                acucarNecessario = 1;
	                break;
	            case "cappuccino":
	                aguaNecessaria = 100;
	                cafeNecessario = 7;
	                acucarNecessario = 2;
	                break;
	            case "latte":
	                aguaNecessaria = 150;
	                cafeNecessario = 7;
	                acucarNecessario = 1;
	                break;
	            default:
	                System.out.println("Tipo de café inválido!");
	                return;
	        }

	        if (agua >= aguaNecessaria && cafe >= cafeNecessario && acucar >= acucarNecessario) {
	            agua -= aguaNecessaria;
	            cafe -= cafeNecessario;
	            acucar -= acucarNecessario;
	            System.out.println("Preparando seu " + tipo + "... Pronto!");
	        } else {
	            System.out.println("Recursos insuficientes para preparar " + tipo + ".");
	        }
	    }

	    public void exibirRecursos() {
	        System.out.println("Recursos restantes -> Água: " + agua + "ml, Café: " + cafe + "g, Açúcar: " + acucar + " colheres");
	    }
	}



