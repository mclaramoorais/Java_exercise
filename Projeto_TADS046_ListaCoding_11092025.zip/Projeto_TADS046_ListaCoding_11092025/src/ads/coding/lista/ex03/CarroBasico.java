package ads.coding.lista.ex03;

public class CarroBasico {
	private boolean ligado;
    private int velocidade;

  
    public CarroBasico() {
        this.ligado = false;
        this.velocidade = 0;
    }

  
    public void ligar() {
        if (!ligado) {
            ligado = true;
            System.out.println("O carro foi ligado.");
        } else {
            System.out.println("O carro já está ligado.");
        }
    }

    public void desligar() {
        if (ligado && velocidade == 0) {
            ligado = false;
            System.out.println("O carro foi desligado.");
        } else if (velocidade > 0) {
            System.out.println("Não é possível desligar o carro em movimento!");
        } else {
            System.out.println("O carro já está desligado.");
        }
    }

    public void acelerar(int incremento) {
        if (ligado) {
            velocidade += incremento;
            System.out.println("O carro acelerou +" + incremento + " km/h. Velocidade atual: " + velocidade + " km/h");
        } else {
            System.out.println("Não é possível acelerar: o carro está desligado.");
        }
    }

    public void frear(int decremento) {
        if (ligado && velocidade > 0) {
            velocidade -= decremento;
            if (velocidade < 0) velocidade = 0;
            System.out.println("O carro freou -" + decremento + " km/h. Velocidade atual: " + velocidade + " km/h");
        } else if (!ligado) {
            System.out.println("Não é possível frear: o carro está desligado.");
        } else {
            System.out.println("O carro já está parado.");
        }
    }

    public String getEstado() {
        return "Carro está " + (ligado ? "ligado" : "desligado") + 
               " | Velocidade atual: " + velocidade + " km/h";
    }
}


