package ads.coding.lista.ex03;

public class App {

	public static void main(String[] args) {
		  CarroBasico carro1 = new CarroBasico();
	        CarroBasico carro2 = new CarroBasico();

	       
	        System.out.println("Carro 1");
	        carro1.ligar();
	        carro1.acelerar(30);
	        carro1.acelerar(20);
	        carro1.frear(15);
	        carro1.desligar(); 
	        carro1.frear(35);  
	        carro1.desligar(); 
	        System.out.println("Estado final Carro 1 -> " + carro1.getEstado());

	        System.out.println();

	    
	        System.out.println("Carro 2");
	        carro2.ligar();
	        carro2.acelerar(50);
	        carro2.frear(10);
	        carro2.frear(40);
	        carro2.desligar();
	        System.out.println("Estado final Carro 2 -> " + carro2.getEstado());
	    }
	}
		