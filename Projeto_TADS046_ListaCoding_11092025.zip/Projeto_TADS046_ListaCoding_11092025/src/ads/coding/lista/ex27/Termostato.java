package ads.coding.lista.ex27;

public class Termostato {
	private int temperaturaAtual;
    private int temperaturaDesejada;
    private String modo;

    public Termostato(int temperaturaInicial) {
        this.temperaturaAtual = temperaturaInicial;
        this.temperaturaDesejada = temperaturaInicial;
        this.modo = "Desligado";
    }

    public void setTemperaturaDesejada(int desejada) {
        if (desejada >= 15 && desejada <= 30) {
            this.temperaturaDesejada = desejada;
            System.out.println("Temperatura desejada definida para: " + temperaturaDesejada + "°C.");
            atualizarModo();
        } else {
            System.out.println("Temperatura desejada inválida. Deve ser entre 15°C e 30°C.");
        }
    }

    public void simularLeituraAtual(int novaLeitura) {
        this.temperaturaAtual = novaLeitura;
        System.out.println("Leitura atual do ambiente: " + temperaturaAtual + "°C.");
        atualizarModo();
    }

    private void atualizarModo() {
        if (temperaturaAtual < temperaturaDesejada) {
            this.modo = "Aquecendo";
        } else if (temperaturaAtual > temperaturaDesejada) {
            this.modo = "Resfriando";
        } else {
            this.modo = "Estável";
        }
        System.out.println("Modo do termostato: " + modo);
    }

    public String getStatus() {
        return "Temp. Atual: " + temperaturaAtual + "°C, Temp. Desejada: " + temperaturaDesejada + "°C, Modo: " + modo;
    }
}