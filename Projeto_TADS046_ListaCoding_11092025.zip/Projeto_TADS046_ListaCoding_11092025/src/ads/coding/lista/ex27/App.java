package ads.coding.lista.ex27;

public class App {

	public static void main(String[] args) {
		System.out.println();
		 
        Termostato ambiente1 = new Termostato(20);
        Termostato ambiente2 = new Termostato(25);

        System.out.println("Status inicial Ambiente 1: " + ambiente1.getStatus());
        System.out.println("Status inicial Ambiente 2: " + ambiente2.getStatus());

       
        System.out.println("\nDemonstração Ambiente 1 (meta 24°C):");
        ambiente1.setTemperaturaDesejada(24);
        ambiente1.simularLeituraAtual(21);
        ambiente1.simularLeituraAtual(23);
        ambiente1.simularLeituraAtual(24);
        System.out.println("Status final Ambiente 1: " + ambiente1.getStatus());

        
        System.out.println("\nDemonstração Ambiente 2 (meta 22°C):");
        ambiente2.setTemperaturaDesejada(22);
        ambiente2.simularLeituraAtual(26);
        ambiente2.simularLeituraAtual(23);
        ambiente2.simularLeituraAtual(22);
        System.out.println("Status final Ambiente 2: " + ambiente2.getStatus());
    
}

}
