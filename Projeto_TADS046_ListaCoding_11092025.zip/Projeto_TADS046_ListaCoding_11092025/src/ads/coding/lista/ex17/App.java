package ads.coding.lista.ex17;

public class App {

	public static void main(String[] args) {
		  Bicicleta bicicleta = new Bicicleta(1, 5);

	        bicicleta.exibirMarcha();
	        bicicleta.pedalar();

	        bicicleta.aumentarMarcha();
	        bicicleta.aumentarMarcha();
	        bicicleta.pedalar();

	        bicicleta.diminuirMarcha();
	        bicicleta.pedalar();

	        bicicleta.aumentarMarcha();
	        bicicleta.aumentarMarcha();
	        bicicleta.aumentarMarcha();
	        bicicleta.aumentarMarcha();
	        bicicleta.pedalar();
	    }
	}