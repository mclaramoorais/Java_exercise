package ads.coding.lista.ex17;

public class Bicicleta {
	  private int marchaAtual;
	    private final int marchaMinima;
	    private final int marchaMaxima;

	    public Bicicleta(int marchaMinima, int marchaMaxima) {
	        this.marchaMinima = marchaMinima;
	        this.marchaMaxima = marchaMaxima;
	        this.marchaAtual = marchaMinima;
	    }

	    public void aumentarMarcha() {
	        if (marchaAtual < marchaMaxima) {
	            marchaAtual++;
	            System.out.println("Marcha aumentada para: " + marchaAtual);
	        } else {
	            System.out.println("Você já está na marcha máxima: " + marchaAtual);
	        }
	    }

	    public void diminuirMarcha() {
	        if (marchaAtual > marchaMinima) {
	            marchaAtual--;
	            System.out.println("Marcha diminuída para: " + marchaAtual);
	        } else {
	            System.out.println("Você já está na marcha mínima: " + marchaAtual);
	        }
	    }

	    public void pedalar() {
	        System.out.println("Pedalando na marcha " + marchaAtual + "...");
	    }

	    public void exibirMarcha() {
	        System.out.println("Marcha atual: " + marchaAtual);
	    }
	}
