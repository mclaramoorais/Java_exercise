package ads.coding.lista.ex26;

public class App {

	public static void main(String[] args) {
		System.out.println("Caixa Registradora");
		 
        CaixaRegistradora caixa1 = new CaixaRegistradora();
        CaixaRegistradora caixa2 = new CaixaRegistradora();
 
        System.out.println("Status inicial Caixa 1: " + caixa1.getStatus());
        System.out.println("Status inicial Caixa 2: " + caixa2.getStatus());
 
        
        System.out.println("\nDemonstração Caixa 1:");
        caixa1.registrarVenda(150.75);
        caixa1.registrarVenda(25.00);
        System.out.println("Status antes de fechar Caixa 1: " + caixa1.getStatus());
        caixa1.fecharCaixa();
        System.out.println("Status após fechar Caixa 1: " + caixa1.getStatus());
 
        
        System.out.println("\nDemonstração Caixa 2:");
        caixa2.registrarVenda(50.00);
        caixa2.registrarVenda(120.50);
        caixa2.registrarVenda(30.00);
        System.out.println("Status antes de fechar Caixa 2: " + caixa2.getStatus());
        caixa2.fecharCaixa();
        System.out.println("Status após fechar Caixa 2: " + caixa2.getStatus());
    }
}