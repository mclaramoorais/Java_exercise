package ads.coding.lista.ex26;

public class CaixaRegistradora {
	private double totalVendas;
	 
    public CaixaRegistradora() {
        this.totalVendas = 0.0;
    }

    public void registrarVenda(double valor) {
        if (valor > 0) {
            this.totalVendas += valor;
            System.out.println("Venda de R$" + String.format("%.2f", valor) + " registrada.");
        } else {
            System.out.println("Valor de venda inválido.");
        }
    }

    public double fecharCaixa() {
        double totalFechamento = this.totalVendas;
        this.totalVendas = 0.0; 
        System.out.println("Caixa fechado. Total de vendas: R$" + String.format("%.2f", totalFechamento));
        return totalFechamento;
    }

    public String getStatus() {
        return "Total de vendas atual: R$" + String.format("%.2f", totalVendas);
    }
}
