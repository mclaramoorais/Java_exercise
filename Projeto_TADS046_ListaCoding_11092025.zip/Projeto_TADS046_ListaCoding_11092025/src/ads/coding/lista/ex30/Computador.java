package ads.coding.lista.ex30;

public class Computador {
	private boolean ligado;
    private String aplicativoAtivo;

    public Computador() {
        this.ligado = false;
        this.aplicativoAtivo = "Nenhum";
    }

    public void ligar() {
        if (!ligado) {
            this.ligado = true;
            System.out.println("Computador ligado.");
        } else {
            System.out.println("Computador já está ligado.");
        }
    }

    public void desligar() {
        if (ligado) {
            this.ligado = false;
            this.aplicativoAtivo = "Nenhum";
            System.out.println("Computador desligado.");
        } else {
            System.out.println("Computador já está desligado.");
        }
    }

    public void reiniciar() {
        if (ligado) {
            System.out.println("Reiniciando computador...");
            this.desligar();
            this.ligar();
            System.out.println("Computador reiniciado.");
        } else {
            System.out.println("Não é possível reiniciar, o computador está desligado.");
        }
    }

    public void abrirAplicativo(String nomeAplicativo) {
        if (ligado) {
            this.aplicativoAtivo = nomeAplicativo;
            System.out.println("Abrindo aplicativo: " + aplicativoAtivo);
        } else {
            System.out.println("Não é possível abrir aplicativo, o computador está desligado.");
        }
    }

    public String getStatus() {
        return "Estado: " + (ligado ? "Ligado" : "Desligado") + ", Aplicativo Ativo: " + aplicativoAtivo;
    }
}
