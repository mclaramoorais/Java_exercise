package ads.coding.lista.ex30;

public class App {

	public static void main(String[] args) {
		System.out.println("Computador");
		 
        Computador meuComputador = new Computador();
 
        System.out.println("Status inicial do computador: " + meuComputador.getStatus());
 
        
        System.out.println("\nLigando e abrindo aplicativos:");
        meuComputador.ligar();
        meuComputador.abrirAplicativo("Navegador");
        System.out.println("Status após abrir Navegador: " + meuComputador.getStatus());
        meuComputador.abrirAplicativo("Editor de Texto");
        System.out.println("Status após abrir Editor de Texto: " + meuComputador.getStatus());
 
 
        System.out.println("\nReiniciando o computador:");
        meuComputador.reiniciar();
        System.out.println("Status após reiniciar: " + meuComputador.getStatus());
 
        
        System.out.println("\nDesligando o computador:");
        meuComputador.desligar();
        System.out.println("Status final: " + meuComputador.getStatus());
    }
}