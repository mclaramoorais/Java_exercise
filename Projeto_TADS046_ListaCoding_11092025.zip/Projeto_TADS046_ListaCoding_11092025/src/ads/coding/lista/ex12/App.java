package ads.coding.lista.ex12;

public class App {

	public static void main(String[] args) {
		  Cronometro cron1 = new Cronometro();
	        Cronometro cron2 = new Cronometro();

	  
	        cron1.iniciar();
	        cron1.incrementar(5);
	        cron1.incrementar(3);
	        cron1.exibirTempo();
	        cron1.parar();

	     
	        cron2.iniciar();
	        cron2.incrementar(10);
	        cron2.incrementar(7);
	        cron2.exibirTempo();
	        cron2.parar();

	        
	        cron1.zerar();
	        cron1.exibirTempo(); 
	    }
	}
