package ads.coding.lista.ex12;

public class Cronometro {
	 private int tempoDecorrido;
	    private boolean rodando;

	    public Cronometro() {
	        this.tempoDecorrido = 0;
	        this.rodando = false;
	    }

	    public void iniciar() {
	        if (!rodando) {
	            rodando = true;
	            System.out.println("Cronômetro iniciado.");
	        } else {
	            System.out.println("Cronômetro já está rodando.");
	        }
	    }

	    public void parar() {
	        if (rodando) {
	            rodando = false;
	            System.out.println("Cronômetro parado.");
	        } else {
	            System.out.println("Cronômetro já estava parado.");
	        }
	    }

	    public void zerar() {
	        tempoDecorrido = 0;
	        rodando = false;
	        System.out.println("Cronômetro zerado (reiniciado para 0s).");
	    }

	    public void incrementar(int segundos) {
	        if (rodando) {
	            tempoDecorrido += segundos;
	            System.out.println("Tempo incrementado em " + segundos + "s.");
	        } else {
	            System.out.println("Não é possível incrementar: cronômetro parado.");
	        }
	    }

	    public void exibirTempo() {
	        System.out.println("Tempo decorrido: " + tempoDecorrido + "s");
	    }
	}
