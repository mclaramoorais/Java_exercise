package br.pe.senac.pi.sementes;

import java.time.LocalDate;

public class PedidoDistribuicao implements Comparable<PedidoDistribuicao> {

    public enum Status {
        PENDENTE,
        ENTREGUE,
        REJEITADO
    }

    private String codigo;
    private String destino;
    private Especie especie;
    private int quantidadeSolicitada;
    private LocalDate dataPedido;
    private LocalDate dataEntrega;
    private Status status;

    public PedidoDistribuicao(String codigo, String destino, Especie especie, int quantidadeSolicitada) {
        validarParametros(codigo, destino, especie, quantidadeSolicitada);
        this.codigo = codigo.trim();
        this.destino = destino.trim();
        this.especie = especie;
        this.quantidadeSolicitada = quantidadeSolicitada;
        this.dataPedido = LocalDate.now();
        this.status = Status.PENDENTE;
        this.dataEntrega = null;
    }

    private void validarParametros(String codigo, String destino, Especie especie, int quantidade) {
        if (codigo == null || codigo.isBlank()) {
            throw new IllegalArgumentException("Código do pedido não pode estar vazio.");
        }
        if (destino == null || destino.isBlank()) {
            throw new IllegalArgumentException("Destino é obrigatório.");
        }
        if (especie == null) {
            throw new IllegalArgumentException("Espécie não pode ser nula.");
        }
        if (quantidade <= 0) {
            throw new IllegalArgumentException("Quantidade solicitada deve ser maior que zero.");
        }
    }

    public String getCodigo() {
        return codigo;
    }

    public String getDestino() {
        return destino;
    }

    public Especie getEspecie() {
        return especie;
    }

    public int getQuantidadeSolicitada() {
        return quantidadeSolicitada;
    }

    public void setQuantidadeSolicitada(int quantidadeSolicitada) {
        if (quantidadeSolicitada < 0) {
            throw new IllegalArgumentException("Quantidade solicitada não pode ser negativa.");
        }
        this.quantidadeSolicitada = quantidadeSolicitada;
    }

    public LocalDate getDataPedido() {
        return dataPedido;
    }

    public LocalDate getDataEntrega() {
        return dataEntrega;
    }

    public Status getStatus() {
        return status;
    }

    public void marcarComoEntregue() {
        if (status == Status.ENTREGUE) {
            throw new IllegalStateException("Pedido já está entregue.");
        }
        this.status = Status.ENTREGUE;
        this.dataEntrega = LocalDate.now();
    }

    public void marcarComoRejeitado() {
        if (status == Status.ENTREGUE) {
            throw new IllegalStateException("Pedido já está entregue e não pode ser rejeitado.");
        }
        this.status = Status.REJEITADO;
    }

    @Override
    public String toString() {
        return String.format(
                "%s - Destino: %s - Espécie: %s - Quantidade: %d %s - Pedido: %s - Status: %s%s",
                codigo,
                destino,
                especie.getNomeComum(),
                quantidadeSolicitada,
                especie.getUnidadeMedida(),
                dataPedido,
                status,
                (dataEntrega != null ? " - Entregue em: " + dataEntrega : "")
        );
    }

    @Override
    public int compareTo(PedidoDistribuicao outro) {
        return this.dataPedido.compareTo(outro.dataPedido);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof PedidoDistribuicao)) return false;
        PedidoDistribuicao outro = (PedidoDistribuicao) obj;
        return codigo.equalsIgnoreCase(outro.codigo);
    }

    @Override
    public int hashCode() {
        return codigo.toLowerCase().hashCode();
    }
}
