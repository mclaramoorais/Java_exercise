package br.pe.senac.pi.sementes;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ServicoEstoque {

    private Armazem armazem;

    public ServicoEstoque(Armazem armazem) {
        if (armazem == null) {
            throw new IllegalArgumentException("Armazém não pode ser nulo.");
        }
        this.armazem = armazem;
    }

    public boolean processarPedido(PedidoDistribuicao pedido) {
        int saldo = calcularSaldoEspecie(pedido.getEspecie());
        return saldo >= pedido.getQuantidadeSolicitada();
    }

    public void realizarBaixaEstoque(PedidoDistribuicao pedido) {
        int quantidade = pedido.getQuantidadeSolicitada();
        if (!processarPedido(pedido)) {
            throw new IllegalStateException("Estoque insuficiente para o pedido " + pedido.getCodigo());
        }

        List<LoteSementes> lotes = armazem.getLotes().stream()
                .filter(l -> l.getEspecie().equals(pedido.getEspecie()))
                .filter(l -> l.getValidade().isAfter(LocalDate.now()) || l.getValidade().isEqual(LocalDate.now()))
                .sorted(Comparator.comparing(LoteSementes::getValidade))
                .collect(Collectors.toList());

        for (LoteSementes lote : lotes) {
            int saldoLote = lote.getQuantidade();
            if (saldoLote >= quantidade) {
                lote.setQuantidade(saldoLote - quantidade);
                quantidade = 0;
                break;
            } else {
                lote.setQuantidade(0);
                quantidade -= saldoLote;
            }
        }

        if (quantidade > 0) {
            throw new IllegalStateException("Erro inesperado: não conseguiu baixar toda a quantidade do pedido.");
        }
    }

    public int calcularSaldoEspecie(Especie especie) {
        return armazem.getLotes().stream()
                .filter(l -> l.getEspecie().equals(especie))
                .filter(l -> l.getValidade().isAfter(LocalDate.now()) || l.getValidade().isEqual(LocalDate.now()))
                .mapToInt(LoteSementes::getQuantidade)
                .sum();
    }

    public void gerarRelatorioEstoque() {
        System.out.println("=== Relatório de Estoque Atual ===");

        armazem.getLotes().stream()
                .filter(l -> l.getQuantidade() > 0)
                .filter(l -> l.getValidade().isAfter(LocalDate.now()) || l.getValidade().isEqual(LocalDate.now()))
                .collect(Collectors.groupingBy(
                        LoteSementes::getEspecie,
                        Collectors.summingInt(LoteSementes::getQuantidade)
                ))
                .forEach((especie, total) -> {
                    System.out.printf("%s: %d %s%n", especie.getNomeComum(), total, especie.getUnidadeMedida());
                });

        System.out.println(" ");
    }
}
