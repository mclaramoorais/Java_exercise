package br.pe.senac.pi.sementes;

import java.util.ArrayList;
import java.util.List;

public class Armazem {

    private String id;
    private String nome;
    private int capacidade;
    private List<LoteSementes> lotes;

    public Armazem(String id, String nome, int capacidade) {
        if (id == null || id.trim().isEmpty())
            throw new IllegalArgumentException("ID do armazém é obrigatório.");
        if (nome == null || nome.trim().isEmpty())
            throw new IllegalArgumentException("Nome do armazém é obrigatório.");
        if (capacidade <= 0)
            throw new IllegalArgumentException("Capacidade do armazém deve ser maior que zero.");

        this.id = id.trim();
        this.nome = nome.trim();
        this.capacidade = capacidade;
        this.lotes = new ArrayList<>();
    }

    public void adicionarLote(LoteSementes lote) {
        if (lote == null)
            throw new IllegalArgumentException("Lote não pode ser nulo.");
        if (lotes.size() >= capacidade)
            throw new IllegalArgumentException("Capacidade do armazém atingida.");
        lotes.add(lote);
    }

    public List<LoteSementes> getLotes() {
        return lotes;
    }

    public String getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public int getCapacidade() {
        return capacidade;
    }

    @Override
    public String toString() {
        return "Armazém: " + nome + " (ID: " + id + "), Capacidade: " + capacidade + ", Lotes cadastrados: " + lotes.size();
    }
}
