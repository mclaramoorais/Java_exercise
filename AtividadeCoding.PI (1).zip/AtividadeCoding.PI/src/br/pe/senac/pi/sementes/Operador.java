package br.pe.senac.pi.sementes;

import java.util.ArrayList;
import java.util.List;

public class Operador extends Pessoa {

    private List<String> funcoes;

    public Operador(String id, String nome, String email, String cpf, String funcaoInicial) {
        super(id, nome, email, cpf);
        this.funcoes = new ArrayList<>();
        if (funcaoInicial != null && !funcaoInicial.isBlank()) {
            this.funcoes.add(funcaoInicial.trim());
        }
    }

    public void adicionarFuncao(String funcao) {
        if (funcao != null && !funcao.isBlank()) {
            this.funcoes.add(funcao.trim());
        }
    }

    public List<String> getFuncoes() {
        return funcoes;
    }

    public String getFuncoesFormatadas() {
        return String.join(", ", funcoes);
    }

    @Override
    public String toString() {
        return super.toString() + " - Operador";
    }
}
