package br.pe.senac.pi.sementes;

public abstract class Pessoa {
    private String id;
    private String nome;
    private String email;
    private String cpf;

    public Pessoa(String id, String nome, String email, String cpf) {
        if (id == null || id.isBlank()) throw new IllegalArgumentException("ID é obrigatório");
        if (nome == null || nome.isBlank()) throw new IllegalArgumentException("Nome é obrigatório");
        if (email == null || email.isBlank()) throw new IllegalArgumentException("Email é obrigatório");
        if (cpf == null || cpf.isBlank()) throw new IllegalArgumentException("CPF é obrigatório");

        this.id = id.trim();
        this.nome = nome.trim();
        this.email = email.trim();
        this.cpf = cpf.trim();
    }

    public String getId() { return id; }
    public String getNome() { return nome; }
    public String getEmail() { return email; }
    public String getCpf() { return cpf; }

    @Override
    public String toString() {
        return nome + " (ID: " + id + ", Email: " + email + ", CPF: " + cpf + ")";
    }
}
