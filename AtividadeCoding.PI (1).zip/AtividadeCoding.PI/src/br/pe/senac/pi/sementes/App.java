package br.pe.senac.pi.sementes;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class App {

    public static void main(String[] args) {
        System.out.println("SISTEMA DE AQUISIÇÃO E DISTRIBUIÇÃO DE SEMENTES");

        try {
            Administrador adm = new Administrador(
                    "0020016006", "Maria Clara",
                    "maria.silva@pe.ipa.br", "97986754330",
                    "Gerencia Agrícola"
            );

            Operador op = new Operador(
                    "0020016006", "Luiz Felipe",
                    "luiz.felipe@pe.ipa.br", "97986754377",
                    "Turno da Manhã"
            );

            System.out.println("Usuários cadastrados:");
            System.out.println(adm);
            System.out.println("Função: " + adm.getDescricaoFuncao());
            System.out.println(op);
            System.out.println("Funções: " + op.getFuncoesFormatadas() + "\n");

            //ESPÉCIES
            Especie aveia = new Especie("Avena sativa", "aveia", "sacos");
            Especie trigo = new Especie("Triticum aestivum", "trigo", "sacos");

            System.out.println("Espécies cadastradas:");
            System.out.println(aveia);
            System.out.println(trigo + "\n");

            //ARMAZÉM
            Armazem armazem = new Armazem("ARMAZEM-003", "Central", 10);

            LoteSementes lote1 = new LoteSementes("LOTE-003", aveia, 500, LocalDate.now().plusMonths(12));
            LoteSementes lote2 = new LoteSementes("LOTE-004", trigo, 750, LocalDate.now().plusMonths(10));

            armazem.adicionarLote(lote1);
            armazem.adicionarLote(lote2);

            System.out.println("Armazém configurado:");
            System.out.println(armazem);
            System.out.println("Lotes cadastrados:");
            for (LoteSementes lote : armazem.getLotes()) {
                System.out.println(lote);
            }
            System.out.println();

            //SERVIÇO DE ESTOQUE
            ServicoEstoque estoque = new ServicoEstoque(armazem);
            System.out.println("Serviço de estoque iniciado!\n");

            //PEDIDOS
            List<PedidoDistribuicao> pedidos = new ArrayList<>();
            pedidos.add(new PedidoDistribuicao("PEDIDO-003", "Timbauba", aveia, 100));
            pedidos.add(new PedidoDistribuicao("PEDIDO-004", "Gravata", trigo, 200));

            System.out.println("Processamento de pedidos:");
            for (PedidoDistribuicao pedido : pedidos) {
                System.out.println("\nPedido: " + pedido.getCodigo() + " - Destino: " + pedido.getDestino());

                if (estoque.processarPedido(pedido)) {
                    estoque.realizarBaixaEstoque(pedido);
                    pedido.marcarComoEntregue();
                    System.out.println("Pedido aprovado e entregue");
                } else {
                    pedido.marcarComoRejeitado();
                    System.out.println("Pedido rejeitado (estoque insuficiente)");
                }
            }

            //RELATÓRIOS 
            System.out.println("\nRelatório de estoque atualizado:");
            estoque.gerarRelatorioEstoque();

            System.out.println("\nResumo dos pedidos:");
            for (PedidoDistribuicao pedido : pedidos) {
                System.out.println(pedido + " | Status: " + pedido.getStatus());
            }

        } catch (Exception e) {
            System.err.println("\n[ERRO] " + e.getMessage());
            e.printStackTrace();
        }

        System.out.println("SISTEMA FINALIZADO");
    }
}
