package br.pe.senac.pi.sementes;

public class Especie {

    private String nomeCientifico;
    private String nomeComum;
    private String unidade; 

    public Especie(String nomeCientifico, String nomeComum, String unidade) {
        if (nomeCientifico == null || nomeCientifico.isBlank())
            throw new IllegalArgumentException("Nome científico é obrigatório");
        if (nomeComum == null || nomeComum.isBlank())
            throw new IllegalArgumentException("Nome comum é obrigatório");
        if (unidade == null || unidade.isBlank())
            throw new IllegalArgumentException("Unidade de medida é obrigatória");

        this.nomeCientifico = nomeCientifico.trim();
        this.nomeComum = nomeComum.trim();
        this.unidade = unidade.trim();
    }

    public String getNomeCientifico() {
        return nomeCientifico;
    }

    public String getNomeComum() {
        return nomeComum;
    }

    public String getUnidade() {
        return unidade;
    }


    public String getUnidadeMedida() {
        return unidade;
    }

    @Override
    public String toString() {
        return nomeComum + " (" + nomeCientifico + ") - Unidade: " + unidade;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Especie)) return false;
        Especie outro = (Especie) obj;
        return nomeCientifico.equalsIgnoreCase(outro.nomeCientifico);
    }

    @Override
    public int hashCode() {
        return nomeCientifico.toLowerCase().hashCode();
    }
}
