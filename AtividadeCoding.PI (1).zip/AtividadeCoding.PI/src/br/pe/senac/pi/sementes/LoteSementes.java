package br.pe.senac.pi.sementes;

import java.time.LocalDate;

public class LoteSementes {

    private String codigo;
    private Especie especie;
    private int quantidade;
    private LocalDate validade;

    public LoteSementes(String codigo, Especie especie, int quantidade, LocalDate validade) {
        if (codigo == null || codigo.isBlank())
            throw new IllegalArgumentException("Código do lote é obrigatório");
        if (especie == null)
            throw new IllegalArgumentException("Espécie é obrigatória");
        if (quantidade <= 0)
            throw new IllegalArgumentException("Quantidade deve ser maior que zero");
        if (validade == null || validade.isBefore(LocalDate.now()))
            throw new IllegalArgumentException("Validade inválida");

        this.codigo = codigo.trim();
        this.especie = especie;
        this.quantidade = quantidade;
        this.validade = validade;
    }

    public String getCodigo() {
        return codigo;
    }

    public Especie getEspecie() {
        return especie;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        if (quantidade < 0)
            throw new IllegalArgumentException("Quantidade não pode ser negativa");
        this.quantidade = quantidade;
    }

    public LocalDate getValidade() {
        return validade;
    }

    @Override
    public String toString() {
        return "Lote " + codigo + " - " + especie.getNomeComum() + " - Quantidade: " + quantidade + " " + especie.getUnidade() + " - Validade: " + validade;
    }
}
