package br.pe.senac.pi.sementes;

public class Administrador extends Pessoa {

    private String descricaoFuncao;

    public Administrador(String id, String nome, String email, String cpf, String descricaoFuncao) {
        super(id, nome, email, cpf);
        if (descricaoFuncao == null || descricaoFuncao.isBlank())
            throw new IllegalArgumentException("Descrição da função é obrigatória");
        this.descricaoFuncao = descricaoFuncao.trim();
    }

    public String getDescricaoFuncao() {
        return descricaoFuncao;
    }

    @Override
    public String toString() {
        return super.toString() + " - Administrador";
    }
}
