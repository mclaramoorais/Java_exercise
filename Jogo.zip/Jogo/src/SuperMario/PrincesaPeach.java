package SuperMario;

public class PrincesaPeach implements Personagem {

    @Override
    public void atacar() {
        System.out.println("Princesa Peach ataca com magia!");
    }

    @Override
    public void defender() {
        System.out.println("Princesa Peach se protege com seu guarda-chuva!");
    }
}
