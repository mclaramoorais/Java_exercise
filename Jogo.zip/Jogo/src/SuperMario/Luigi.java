package SuperMario;

public class Luigi implements Personagem {

    @Override
    public void atacar() {
        System.out.println("Luigi ataca com salto longo, atingindo inimigos à distância!");
    }

    @Override
    public void defender() {
        System.out.println("Luigi se defende com sua agilidade e esquiva rápida!");
    }
}
