package SuperMario;

public class Mario implements Personagem {

    @Override
    public void atacar() {
        System.out.println("Mario ataca com pulo sobre o inimigo!");
    }

    @Override
    public void defender() {
        System.out.println("Mario se protege com casco de tartaruga!");
    }
}
