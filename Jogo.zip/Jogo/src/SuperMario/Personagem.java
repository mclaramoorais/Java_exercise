package SuperMario;

public interface Personagem {
    // Ataque do Personagem
    void atacar();

    // Defesa do Personagem
    void defender();
}
