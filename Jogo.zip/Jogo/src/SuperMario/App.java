package SuperMario;

public class App {
    public static void main(String[] args) {
    	
        Personagem Mario = new Mario(); 
        Personagem Luigi = new Luigi();
        Personagem Bowser = new Bowser();
        Personagem PrincesaPeach = new PrincesaPeach();

        System.out.println("Ações dos personagens:");
        Mario.atacar();
        Mario.defender();

        Luigi.atacar();
        Luigi.defender();

        Bowser.atacar();
        Bowser.defender();

        PrincesaPeach.atacar();
        PrincesaPeach.defender();
    }
}
