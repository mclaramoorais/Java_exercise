package SuperMario;

public class Bowser implements Personagem {

    @Override
    public void atacar() {
        System.out.println("Bowser ataca com fogo!");
    }

    @Override
    public void defender() {
        System.out.println("Bowser se defende com sua couraça!");
    }
}
